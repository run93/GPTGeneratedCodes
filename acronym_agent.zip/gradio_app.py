# gradio_app.py
# Gradio dashboard for acronym agent outputs + run-on-custom-text + per-run summary
# Shows: total tokens, known normal words count, unknown normal words list,
# new words added, new acronyms/expansions, unknown updates.

import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import gradio as gr

import agent as ag  # imports AcronymAgent + split_into_paragraphs

DATA_DIR = Path("data")
KNOWN_PATH = DATA_DIR / "known_acronyms.json"
UNKNOWN_PATH = DATA_DIR / "unknown_acronyms.json"
WORDLIST_PATH = DATA_DIR / "word_list.txt"


# -----------------------------
# IO helpers
# -----------------------------
def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def load_words(path: Path) -> List[str]:
    if not path.exists():
        return []
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def normalize_known(known: Any) -> Dict[str, List[str]]:
    if not isinstance(known, dict):
        return {}
    out: Dict[str, List[str]] = {}
    for k, v in known.items():
        kk = str(k).strip()
        if not kk:
            continue
        if isinstance(v, str):
            out[kk] = [v]
        elif isinstance(v, list):
            out[kk] = [str(x).strip() for x in v if str(x).strip()]
        else:
            out[kk] = []
    return out


def normalize_unknown(unknown: Any) -> Dict[str, List[Dict[str, str]]]:
    if not isinstance(unknown, dict):
        return {}
    out: Dict[str, List[Dict[str, str]]] = {}
    for k, arr in unknown.items():
        kk = str(k).strip()
        if not kk or not isinstance(arr, list):
            continue
        items = []
        for it in arr:
            if not isinstance(it, dict):
                continue
            items.append(
                {
                    "context": str(it.get("context", "")).strip(),
                    "note": str(it.get("note", "")).strip(),
                }
            )
        out[kk] = items
    return out


def load_state() -> Dict[str, Any]:
    return {
        "known": normalize_known(load_json(KNOWN_PATH, {})),
        "unknown": normalize_unknown(load_json(UNKNOWN_PATH, {})),
        "words": load_words(WORDLIST_PATH),
    }


# -----------------------------
# Display formatting
# -----------------------------
def build_stats_md(known: Dict[str, List[str]], unknown: Dict[str, List[Dict[str, str]]], words: List[str]) -> str:
    poly = sorted([(k, len(v)) for k, v in known.items()], key=lambda x: x[1], reverse=True)[:10]
    poly_md = "\n".join([f"- `{k}`: {n} expansions" for k, n in poly]) or "- (none)"

    return (
        "## Stats\n"
        f"- Known acronyms: **{len(known)}**\n"
        f"- Unknown acronyms: **{len(unknown)}**\n"
        f"- Updated word list size: **{len(words)}**\n\n"
        "## Top polysemy (by #expansions)\n"
        f"{poly_md}\n"
    )


def format_known_md(known: Dict[str, List[str]], q: str) -> str:
    ql = (q or "").strip().lower()
    lines = []
    for k in sorted(known.keys()):
        exps = known.get(k, [])
        if ql:
            if ql not in k.lower() and not any(ql in (e or "").lower() for e in exps):
                continue
        lines.append(f"### `{k}`  ({len(exps)} expansions)")
        if exps:
            for e in exps:
                lines.append(f"- {e}")
        else:
            lines.append("- *(empty)*")
        lines.append("")
    return "\n".join(lines) if lines else "_No results._"


def format_unknown_md(unknown: Dict[str, List[Dict[str, str]]], q: str, max_ctx_per_term: int = 10) -> str:
    ql = (q or "").strip().lower()
    lines = []
    for k in sorted(unknown.keys()):
        items = unknown.get(k, [])
        if ql:
            hit = ql in k.lower()
            if not hit:
                for it in items:
                    if ql in (it.get("context", "").lower()) or ql in (it.get("note", "").lower()):
                        hit = True
                        break
            if not hit:
                continue

        lines.append(f"### `{k}`  ({len(items)} contexts)")
        show_items = items[:max_ctx_per_term]
        for idx, it in enumerate(show_items, 1):
            note = it.get("note", "")
            ctx = it.get("context", "")
            if note:
                lines.append(f"**{idx}. note:** {note}")
            lines.append(f"**{idx}. context:** {ctx}")
            lines.append("")
        if len(items) > max_ctx_per_term:
            lines.append(f"_... truncated, showing first {max_ctx_per_term} contexts._")
            lines.append("")
    return "\n".join(lines) if lines else "_No results._"


def format_words_md(words: List[str], q: str, limit: int = 2000) -> str:
    ql = (q or "").strip().lower()
    out = []
    for w in words:
        if not w:
            continue
        if ql and ql not in w.lower():
            continue
        out.append(w)
        if len(out) >= limit:
            break
    if not out:
        return "_No results._"
    return "\n".join([f"- {w}" for w in out])


def refresh_ui(q: str) -> Tuple[str, str, str, str]:
    st = load_state()
    known, unknown, words = st["known"], st["unknown"], st["words"]
    return (
        build_stats_md(known, unknown, words),
        format_known_md(known, q),
        format_unknown_md(unknown, q),
        format_words_md(words, q),
    )


# -----------------------------
# Run summary (before vs after)
# -----------------------------
def tokenize_all_words(text: str) -> List[str]:
    # close to agent tokenization style
    return re.findall(r"\b[A-Za-z][A-Za-z0-9_\-]*\b", text or "")


def compute_run_summary(text: str, before: Dict[str, Any], after: Dict[str, Any]) -> str:
    tokens = tokenize_all_words(text)
    total_words = len(tokens)

    before_words = set(before["words"])
    after_words = set(after["words"])

    # 已知普通词：运行前就存在于 word list 的 token（小写匹配）
    known_words = sum(1 for t in tokens if t.lower() in before_words)

    # 未知普通词：运行前不在 word list，且不是短全大写 acronym-like（FY/FICA/TLS/UC...）
    unknown_words = sorted({
        t.lower()
        for t in tokens
        if t.lower() not in before_words
        and not (len(t) <= 4 and t.isupper())
    })

    # 新增普通词：after - before
    new_words = sorted(after_words - before_words)

    before_known = before["known"]
    after_known = after["known"]

    # 新增 acronym key
    new_acronyms = sorted(set(after_known.keys()) - set(before_known.keys()))

    # 新增 expansions
    new_expansion_events = []
    for k, exps_after in after_known.items():
        exps_before = before_known.get(k, [])
        added = [e for e in exps_after if e not in exps_before]
        if added:
            new_expansion_events.append((k, added))

    # unknown changes
    before_unknown = before["unknown"]
    after_unknown = after["unknown"]
    new_unknown_keys = sorted(set(after_unknown.keys()) - set(before_unknown.keys()))
    new_unknown_items = 0
    for k, arr_after in after_unknown.items():
        arr_before = before_unknown.get(k, [])
        if isinstance(arr_after, list) and isinstance(arr_before, list):
            if len(arr_after) > len(arr_before):
                new_unknown_items += (len(arr_after) - len(arr_before))

    lines = []
    lines.append("## Run Summary")
    lines.append(f"- 本次输入总词数（tokens）：**{total_words}**")
    lines.append(f"- 运行前已知普通词（在 updated_word_list.txt 中）：**{known_words}**")

    lines.append(f"- 未知普通词（本次输入中）：**{len(unknown_words)}**")
    if unknown_words:
        preview = ", ".join(unknown_words[:30])
        lines.append(f"  - 具体词语（最多30个）：`{preview}`" + (" ..." if len(unknown_words) > 30 else ""))

    lines.append(f"- 新增普通词（写入 updated_word_list.txt）：**{len(new_words)}**")
    if new_words:
        preview = ", ".join(new_words[:30])
        lines.append(f"  - 新增词示例（最多30个）：`{preview}`" + (" ..." if len(new_words) > 30 else ""))

    lines.append("")
    lines.append("## Acronym Updates")
    lines.append(f"- 新增 acronym（key）：**{len(new_acronyms)}**")
    if new_acronyms:
        lines.append("  - " + ", ".join([f"`{x}`" for x in new_acronyms[:30]]) + (" ..." if len(new_acronyms) > 30 else ""))

    lines.append(f"- 新增 expansions（含多义新增）：**{sum(len(v) for _, v in new_expansion_events)}**")
    if new_expansion_events:
        lines.append("")
        lines.append("### Expansion details (top 10)")
        for k, added in new_expansion_events[:10]:
            lines.append(f"- `{k}`: " + "; ".join([f"**{e}**" for e in added]))

    lines.append("")
    lines.append("## Unknown Updates")
    lines.append(f"- 新增 unknown acronym（key）：**{len(new_unknown_keys)}**")
    lines.append(f"- unknown 新增 context 条目数：**{new_unknown_items}**")

    return "\n".join(lines)


def run_agent_on_text(q: str, text: str, model_name: str, temperature: float):
    t0 = time.perf_counter()

    t_load_before_0 = time.perf_counter()
    before = load_state()
    t_load_before_1 = time.perf_counter()

    if not (text or "").strip():
        summary = "## Run Summary\n- 输入为空，本次未处理。"
        t_refresh_0 = time.perf_counter()
        stats_md, known_md, unknown_md, words_md = refresh_ui(q)
        t_refresh_1 = time.perf_counter()
        timing = (
            "\n\n---\n"
            "## Timing\n"
            f"- load_state(before): **{(t_load_before_1 - t_load_before_0)*1000:.1f} ms**\n"
            f"- refresh_ui: **{(t_refresh_1 - t_refresh_0)*1000:.1f} ms**\n"
            f"- total: **{(t_refresh_1 - t0)*1000:.1f} ms**\n"
        )
        return summary + timing, stats_md, known_md, unknown_md, words_md

    paragraphs = ag.split_into_paragraphs(text)

    t_agent_init_0 = time.perf_counter()
    agent = ag.AcronymAgent(
        data_dir=DATA_DIR,
        llm_model=(model_name or "").strip() or "deepseek-r1:8b",
        temperature=float(temperature),
    )
    t_agent_init_1 = time.perf_counter()

    t_process_0 = time.perf_counter()
    for p in paragraphs:
        agent.process_paragraph(p)
    agent.persist()
    t_process_1 = time.perf_counter()

    t_load_after_0 = time.perf_counter()
    after = load_state()
    t_load_after_1 = time.perf_counter()

    t_summary_0 = time.perf_counter()
    summary = compute_run_summary(text, before, after)
    t_summary_1 = time.perf_counter()

    t_refresh_0 = time.perf_counter()
    stats_md, known_md, unknown_md, words_md = refresh_ui(q)
    t_refresh_1 = time.perf_counter()

    timing = (
        "\n\n---\n"
        "## Timing\n"
        f"- load_state(before): **{(t_load_before_1 - t_load_before_0)*1000:.1f} ms**\n"
        f"- AcronymAgent init: **{(t_agent_init_1 - t_agent_init_0)*1000:.1f} ms**\n"
        f"- process_paragraph + persist: **{(t_process_1 - t_process_0)*1000:.1f} ms**\n"
        f"- load_state(after): **{(t_load_after_1 - t_load_after_0)*1000:.1f} ms**\n"
        f"- compute_run_summary: **{(t_summary_1 - t_summary_0)*1000:.1f} ms**\n"
        f"- refresh_ui (render strings): **{(t_refresh_1 - t_refresh_0)*1000:.1f} ms**\n"
        f"- total: **{(t_refresh_1 - t0)*1000:.1f} ms**\n"
    )

    return summary + timing, stats_md, known_md, unknown_md, words_md


# -----------------------------
# Gradio UI
# -----------------------------
with gr.Blocks(title="Acronym Dictionary Dashboard") as demo:
    gr.Markdown("# Acronym Dictionary Dashboard (Gradio)\nLocal visualization for known/unknown dictionaries + updated word list.")

    with gr.Row():
        query = gr.Textbox(
            label="Search",
            placeholder="Search acronym / expansion / context / note / word (e.g., BK / TLS / UC / FICA)",
        )
        refresh_btn = gr.Button("Refresh")

    with gr.Accordion("Run Agent on custom text", open=True):
        custom_text = gr.Textbox(
            label="Text chunk to process",
            placeholder="Paste one or more paragraphs here...\n\nExample:\nAbout the FY 2024 ...\nFICA (Federal Insurance Contributions Act) is a law ...",
            lines=10,
        )
        with gr.Row():
            model_name = gr.Textbox(label="Ollama model", value="deepseek-r1:8b")
            temperature = gr.Slider(label="temperature", minimum=0.0, maximum=1.0, step=0.05, value=0.2)
        run_btn = gr.Button("Run Agent on Text")
        summary_md = gr.Markdown()

    with gr.Tabs():
        with gr.Tab("Stats"):
            stats_md = gr.Markdown()
        with gr.Tab("Known"):
            known_md = gr.Markdown()
        with gr.Tab("Unknown"):
            unknown_md = gr.Markdown()
        with gr.Tab("Word List"):
            words_md = gr.Markdown()

    demo.load(fn=refresh_ui, inputs=[query], outputs=[stats_md, known_md, unknown_md, words_md])
    refresh_btn.click(fn=refresh_ui, inputs=[query], outputs=[stats_md, known_md, unknown_md, words_md])
    query.submit(fn=refresh_ui, inputs=[query], outputs=[stats_md, known_md, unknown_md, words_md])

    run_btn.click(
        fn=run_agent_on_text,
        inputs=[query, custom_text, model_name, temperature],
        outputs=[summary_md, stats_md, known_md, unknown_md, words_md],
    )

if __name__ == "__main__":
    demo.launch(server_name="127.0.0.1", server_port=7860)
