# agent.py
# Local LLM agent for Acronym & Abbreviation Expansion
# Strict 7-step workflow (with safe engineering guards).
#
# Data stores (under ./data):
# 1) word_list.txt                (seed common words; init contains "hello")  (READ ONLY seed)
# 2) known_acronyms.json          (dict: acronym -> list[str] expansions) (READ/WRITE)
# 3) unknown_acronyms.json        (dict: acronym -> list[ {context, note} ]) (READ/WRITE)
# 4) input.txt                    (optional; paragraphs separated by blank lines)
#
# IMPORTANT:
# - No *_tmp.json.
# - Non-acronym words go to word_list_path.txt (with a strong guard to avoid poisoning).
# - Parenthetical patterns like "FICA (Federal Insurance Contributions Act)" are deterministically extracted.
#
# Run:
#   pip install -U langchain langchain-core langchain-community pydantic
#   ollama pull deepseek-r1:8b   (or your model)
#   python agent.py

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, ValidationError

from langchain_community.chat_models import ChatOllama
try:
    from langchain_core.messages import HumanMessage
except ModuleNotFoundError:
    from langchain.schema import HumanMessage

try:
    from langchain.prompts import PromptTemplate
except ModuleNotFoundError:
    from langchain_core.prompts import PromptTemplate


# -----------------------------
# Helpers: file IO
# -----------------------------
def ensure_file(path: Path, default_text: str) -> None:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(default_text, encoding="utf-8")


def load_word_list(path: Path) -> set:
    """
    Read seed common word list.
    This file is treated as READ ONLY seed list.
    """
    ensure_file(path, "hello\n")
    return {line.strip().lower() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()}


def save_word_list(path: Path, words: set) -> None:
    """
    Write updated word list (dedup + sorted).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = sorted({w.strip().lower() for w in words if w and w.strip()})
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return default


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def acronym_key(term: str) -> str:
    return term.strip().upper()


def norm_expansion(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s


def looks_like_acronym(term: str) -> bool:
    t = (term or "").strip()
    return len(t) <= 4 and t.isupper() and t.isalpha()


# -----------------------------
# Safety guard: NEVER poison word list with acronym-like tokens
# -----------------------------
def safe_to_add_to_word_list(term: str) -> bool:
    """
    Allow normal words (including Capitalized ones),
    block ONLY acronym-like tokens (ALL CAPS).
    """
    if not term:
        return False

    t = term.strip()

    # Block ALL-CAPS tokens (likely acronyms)
    if t.isupper():
        return False

    # Too short -> block
    if len(t) <= 2:
        return False

    # Contains digits -> block (optional, keep if you want)
    if any(c.isdigit() for c in t):
        return False

    return True


# -----------------------------
# Deterministic extraction: ACRONYM (Expansion)
# -----------------------------
def extract_parenthetical_expansions(paragraph: str) -> Dict[str, str]:
    """
    High-precision extraction for patterns like:
      FICA (Federal Insurance Contributions Act)
    Returns dict: { "FICA": "Federal Insurance Contributions Act" }
    """
    out: Dict[str, str] = {}
    if not paragraph:
        return out

    pattern = r"\b([A-Z][A-Z0-9]{1,12})\s*\(([^)]+)\)"
    for acro, exp in re.findall(pattern, paragraph):
        acro = acronym_key(acro)
        exp = (exp or "").strip()
        if not exp:
            continue
        # small sanity: expansion should look like words not just a symbol blob
        if len(exp) < 3:
            continue
        out[acro] = exp
    return out


# -----------------------------
# Step2: Function1 - tokenize and subtract common words => unseen list
# -----------------------------

def extract_unseen_words(paragraph: str, common_words: set, known_keys: set) -> List[str]:
    """
    Tokens like: XKG, UC, IL-6, TLS, etc.
    We treat as "words" candidates if start with a letter.
    """
    tokens = re.findall(r"\b[A-Za-z][A-Za-z0-9_\-]{1,}\b", paragraph)
    seen = set()
    out: List[str] = []

    for t in tokens:
        tl = t.lower()
        
        # 1. Skip if it's a common word (e.g., "the", "hello")
        if tl in common_words:
            continue
            
        # 2. NEW: Skip if we already know this acronym (e.g., "DEIA")
        # We check both the raw token (DEIA) and upper (DEIA)
        if t in known_keys or t.upper() in known_keys:
            continue

        if tl in seen:
            continue
            
        seen.add(tl)
        out.append(t)

    return out


# -----------------------------
# Step4: prompt_1 output schema (classification only)
# -----------------------------
class ClassifyItem(BaseModel):
    term: str
    is_common_word: bool = Field(..., description="true if this is a normal/common word (not acronym/abbrev)")
    is_acronym_or_abbrev: bool = Field(..., description="true if acronym/abbrev")
    note: str = Field(default="", description="Short explanation")


class ClassifyResult(BaseModel):
    items: List[ClassifyItem]


# -----------------------------
# Step6: prompt_2 output schema (align with existing expansions)
# -----------------------------
class AlignResult(BaseModel):
    term: str
    matches_existing: bool = Field(..., description="true if paragraph meaning matches any existing expansions")
    new_expansions: List[str] = Field(default_factory=list, description="new expansions not in existing list")
    note: str = Field(default="")


# -----------------------------
# Step7: prompt_3 output schema (infer expansion or unknown)
# -----------------------------
class InferResult(BaseModel):
    term: str
    determined: bool = Field(..., description="true if you can determine expansion from context")
    expansions: List[str] = Field(default_factory=list, description="1-3 expansions if determined")
    note: str = Field(default="")


# -----------------------------
# Robust JSON extraction & coercion (models sometimes output arrays)
# -----------------------------
def extract_json_block(text: str) -> Optional[str]:
    t = (text or "").strip()
    m = re.search(r"(\{.*\}|\[.*\])", t, flags=re.DOTALL)
    return m.group(1) if m else None


def parse_model_json(raw: str) -> Any:
    block = extract_json_block(raw) or raw
    try:
        return json.loads(block)
    except Exception:
        return None


# -----------------------------
# Prompts
# -----------------------------
def build_prompt_1() -> PromptTemplate:
    return PromptTemplate(
        template="""
You are an expert linguistic analyzer specializing in identifying non-standard terminology.

TASK:
Classify each term in the TERMS list based on the provided PARAGRAPH.

CATEGORIES & RULES:
1. is_common_word (STRICT):
   - Set to TRUE only if the term is a standard, full English word found in a general dictionary (e.g., "guidelines", "conference", "table").
   - Set to FALSE if it is a technical ID, a software package, or a domain-specific shorthand.

2. is_acronym_or_abbrev (BROAD):
   - Set to TRUE if the term falls into any of these categories:
     * Acronyms: All-caps (e.g., NASA, DEIA).
     * Abbreviations: Shortened forms (e.g., "approx", "cls").
     * Concatenated Words: Merged words or "code-like" strings (e.g., "trdcnt" for trade count, "acmart", "sysinfo").
     * Technical Identifiers: Filenames, extensions, or library names.

If a term is a common word used as a variable/shorthand in this context, prioritize setting is_acronym_or_abbrev to TRUE.

PARAGRAPH:
\"\"\"{paragraph}\"\"\"

TERMS:
{terms}

Return ONLY JSON:
{{
  "items": [
    {{"term":"trdcnt", "is_common_word":false, "is_acronym_or_abbrev":true, "note":"concatenated shorthand for trade count"}},
    {{"term":"guidelines", "is_common_word":true, "is_acronym_or_abbrev":false, "note":"standard English word"}}
  ]
}}
""".strip(),
        input_variables=["paragraph", "terms"],
    )


def build_prompt_2() -> PromptTemplate:
    return PromptTemplate(
        template="""
You are an expert in terminology disambiguation.

TASK:
Determine if the usage of the TERM in the PARAGRAPH matches any of the EXISTING_EXPANSIONS.

RULES:
- TERM can be an acronym, an abbreviation, or a concatenated word (e.g., "trdcnt").
- Compare the context of the paragraph with the provided expansions.
- If the meaning is identical or highly similar, set matches_existing=true.
- If the paragraph suggests a new meaning, or if the current expansion is missing, provide it in new_expansions.

EXAMPLES:
1. TERM: "UC"
   EXISTING_EXPANSIONS: ["University of California", "User Choice"]
   PARAGRAPH: "The student applied to UC Berkeley."
   RESULT: {{ "term": "UC", "matches_existing": true, "new_expansions": [], "note": "Matches University of California context." }}

2. TERM: "trdcnt"
   EXISTING_EXPANSIONS: ["trade count"]
   PARAGRAPH: "The trend count (trdcnt) was calculated daily."
   RESULT: {{ "term": "trdcnt", "matches_existing": false, "new_expansions": ["trend count"], "note": "Context implies trend count, not trade count." }}

PARAGRAPH:
\"\"\"{paragraph}\"\"\"

TERM: {acronym}
EXISTING_EXPANSIONS: {existing}

Return ONLY JSON.
""".strip(),
        input_variables=["paragraph", "acronym", "existing"],
    )


def build_prompt_3() -> PromptTemplate:
    return PromptTemplate(
        template="""
You extract definitions for abbreviations and concatenated terms from text.

TASK:
Decide if the PARAGRAPH explicitly or implicitly defines the TERM.

DEFINITION PATTERNS:
1. Parentheses: TERM (Full Form) or Full Form (TERM).
2. Explicit markers: "TERM stands for...", "TERM defined as...", "TERM meaning...".
3. Concatenation logic: For terms like "trdcnt", look for nearby phrases like "the trade count is...".

EXAMPLES:
1. TERM: "FICA"
   PARAGRAPH: "The Federal Insurance Contributions Act (FICA) is a tax."
   RESULT: {{ "term": "FICA", "determined": true, "expansions": ["Federal Insurance Contributions Act"], "note": "Direct parenthetical definition." }}

2. TERM: "trdcnt"
   PARAGRAPH: "We calculated the trdcnt. This trade count helps us track volume."
   RESULT: {{ "term": "trdcnt", "determined": true, "expansions": ["trade count"], "note": "Implicit definition found in subsequent sentence." }}

DETERMINED = true only if the expansion is clearly present in the text.
Do not use outside knowledge to guess if the text doesn't support it.

PARAGRAPH:
\"\"\"{paragraph}\"\"\"

TERM: {acronym}

Return ONLY JSON with keys:
{{
  "term": "{acronym}",
  "determined": true/false,
  "expansions": ["expansion1", ...],
  "note": "reasoning"
}}
""".strip(),
        input_variables=["paragraph", "acronym"],
    )


# -----------------------------
# Agent
# -----------------------------
@dataclass
class AcronymAgent:
    data_dir: Path
    llm_model: str = "deepseek-r1:8b"
    temperature: float = 0.2

    def __post_init__(self):
        # word lists
        self.word_list_path = self.data_dir / "word_list.txt"                 # seed (read)

        # persistent acronym stores
        self.known_path = self.data_dir / "known_acronyms.json"
        self.unknown_path = self.data_dir / "unknown_acronyms.json"

        # load word list
        self.common_words = load_word_list(self.word_list_path)

        # Merge updated word list (if exists) so "about" will also match "About"
        if self.word_list_path.exists():
            updated = {
                line.strip().lower()
                for line in self.word_list_path.read_text(encoding="utf-8").splitlines()
                if line.strip()
            }
            self.common_words |= updated

        # load known/unknown
        self.known: Dict[str, List[str]] = load_json(self.known_path, {})
        if not isinstance(self.known, dict):
            self.known = {}
        for k, v in list(self.known.items()):
            if isinstance(v, str):
                self.known[k] = [v]
            elif isinstance(v, list):
                self.known[k] = [str(x) for x in v if str(x).strip()]
            else:
                self.known[k] = []

        self.unknown: Dict[str, List[Dict[str, str]]] = load_json(self.unknown_path, {})
        if not isinstance(self.unknown, dict):
            self.unknown = {}

        # LLM & prompts
        self.chat = ChatOllama(model=self.llm_model, temperature=self.temperature)
        self.prompt_1 = build_prompt_1()
        self.prompt_2 = build_prompt_2()
        self.prompt_3 = build_prompt_3()

    def _invoke(self, text: str) -> str:
        msg = self.chat.invoke([HumanMessage(content=text)])
        return getattr(msg, "content", str(msg))

    # Step4: prompt_1
    def classify_terms(self, paragraph: str, terms: List[str]) -> Optional[ClassifyResult]:
        prompt = self.prompt_1.format(paragraph=paragraph, terms=json.dumps(terms, ensure_ascii=False))
        raw = self._invoke(prompt)
        obj = parse_model_json(raw)
        if obj is None:
            return None
        if isinstance(obj, list):
            obj = {"items": obj}
        try:
            return ClassifyResult.model_validate(obj)
        except ValidationError:
            return None

    # Step6: prompt_2
    def align_with_existing(self, paragraph: str, acronym: str, existing: List[str]) -> Optional[AlignResult]:
        prompt = self.prompt_2.format(
            paragraph=paragraph,
            acronym=acronym,
            existing=json.dumps(existing, ensure_ascii=False),
        )
        raw = self._invoke(prompt)
        obj = parse_model_json(raw)
        if obj is None:
            return None
        if isinstance(obj, list) and obj:
            obj = obj[0]
        try:
            return AlignResult.model_validate(obj)
        except ValidationError:
            return None

    # Step7: prompt_3
    def infer_expansion(self, paragraph: str, acronym: str) -> Optional[InferResult]:
        prompt = self.prompt_3.format(paragraph=paragraph, acronym=acronym)
        raw = self._invoke(prompt)
        obj = parse_model_json(raw)
        if obj is None:
            return None
        if isinstance(obj, list) and obj:
            obj = obj[0]
        try:
            return InferResult.model_validate(obj)
        except ValidationError:
            return None

    def persist(self) -> None:
        save_json(self.known_path, self.known)
        save_json(self.unknown_path, self.unknown)
        save_word_list(self.word_list_path, self.common_words)

    def process_paragraph(self, paragraph: str) -> None:
        # Step1: read paragraph
        paragraph = (paragraph or "").strip()
        if not paragraph:
            return

        # Deterministic extraction: ACRONYM (Expansion)
        # This is safe, fast, and prevents "FICA (...) not added" issues.
        paren = extract_parenthetical_expansions(paragraph)
        if paren:
            changed = False
            for acro, exp in paren.items():
                existing = self.known.get(acro, [])
                exp_norm = norm_expansion(exp)
                if exp_norm and all(norm_expansion(e) != exp_norm for e in existing):
                    existing.append(exp)
                    self.known[acro] = existing
                    changed = True

            # ✅ only persist if dictionary actually changed
            if changed:
                self.persist()

        # Step2: unseen words
        unseen = extract_unseen_words(paragraph, self.common_words, set(self.known.keys()))

        # Step3: if none, end
        if not unseen:
            return

        # Step4: classify
        classified = self.classify_terms(paragraph, unseen)
        if not classified:
            return

        dirty = False  # <-- 新增：本段是否有任何写入变化

        for item in classified.items:
            term = (item.term or "").strip()
            if not term:
                continue

            force_acro = looks_like_acronym(term)

            if not force_acro:
                if item.is_common_word and not item.is_acronym_or_abbrev:
                    if safe_to_add_to_word_list(term):
                        tl = term.lower()
                        if tl not in self.common_words:   # <-- 新增：只有真正新增才 dirty
                            self.common_words.add(tl)
                            dirty = True
                    continue

                if not item.is_acronym_or_abbrev:
                    continue

            key = acronym_key(term)

            if key in self.known and self.known.get(key):
                existing = self.known.get(key, [])
                align = self.align_with_existing(paragraph, key, existing)
                if not align:
                    continue
                if align.matches_existing:
                    continue

                new_exps = [e.strip() for e in (align.new_expansions or []) if e and e.strip()]
                if new_exps:
                    existing_norm = {norm_expansion(x) for x in existing}
                    for e in new_exps:
                        ne = norm_expansion(e)
                        if ne and ne not in existing_norm:
                            existing.append(e)
                            existing_norm.add(ne)
                            dirty = True
                    self.known[key] = existing
                continue

            # Step7: infer
            infer = self.infer_expansion(paragraph, key)
            if not infer:
                continue

            if infer.determined and infer.expansions:
                exps = [e.strip() for e in infer.expansions if e and e.strip()]
                if exps:
                    if key not in self.known or self.known[key] != exps:
                        self.known[key] = exps
                        dirty = True
            else:
                self.unknown.setdefault(key, [])
                self.unknown[key].append({"context": paragraph, "note": infer.note if infer else "not enough context"})
                dirty = True

        if dirty:
            self.persist()

# -----------------------------
# Input helper (optional)
# -----------------------------
def load_input_document(path: Path) -> str:
    ensure_file(path, "")
    return path.read_text(encoding="utf-8")


def split_into_paragraphs(text: str) -> List[str]:
    text = (text or "").strip()
    if not text:
        return []
    parts = re.split(r"\n\s*\n+", text)
    return [p.strip() for p in parts if p.strip()]


if __name__ == "__main__":
    data_dir = Path("data")
    input_path = data_dir / "input.txt"
    ensure_file(input_path, "")

    doc = load_input_document(input_path)
    paragraphs = split_into_paragraphs(doc)

    agent = AcronymAgent(
        data_dir=data_dir,
        llm_model="deepseek-r1:8b",
        temperature=0.2,
    )

    for p in paragraphs:
        agent.process_paragraph(p)

    agent.persist()
